<?php
include 'connection.php';

// Check if the form is submitted and required fields are set
if (isset($_POST['tobealloted']) && isset($_POST['toalloted']) && isset($_POST['section'])) {
    $subject = $_POST['tobealloted'];
    $teacher = $_POST['toalloted'];
    $section = $_POST['section'];

    // Establish connection
    $conn = mysqli_connect("localhost", "root", "", "ttms");

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Check if the same teacher has already been allotted the same subject for the same section
    $checkQuery = "SELECT * FROM subjects WHERE subject_code='$subject' AND section='$section' AND allotedto='$teacher'";
    $checkResult = mysqli_query($conn, $checkQuery);

    if (mysqli_num_rows($checkResult) > 0) {
        // If the teacher is already allotted the subject for that section
        echo "<script>alert('This subject has already been allotted to the teacher for the selected section.');</script>";
    } else {
        // Proceed with allotment
        header("Location: allotsubjects.php?tobealloted=$subject&toalloted=$teacher§ion=$section");
    }

    // Close the connection
    mysqli_close($conn);
} else {
    echo "<script>alert('Please select a subject, teacher, and section.');</script>";
    die();
}
?>
