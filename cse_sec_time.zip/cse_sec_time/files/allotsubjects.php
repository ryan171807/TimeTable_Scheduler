<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start the session at the very beginning of the script
session_start();

// Database connection
$conn = new mysqli("localhost", "root", "", "ttms");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form inputs
    $subjects = isset($_POST['subjects']) ? $_POST['subjects'] : [];
    $toalloted = isset($_POST['toalloted']) ? $_POST['toalloted'] : null;
    $section = isset($_POST['section']) ? $_POST['section'] : null;

    // Check if all required inputs are provided
    if ($toalloted && $section && !empty($subjects)) {
        // Begin transaction
        $conn->begin_transaction();

        try {
            // Insert each selected subject into the subject_allocation table
            foreach ($subjects as $subject_code) {
                // Check if the subject is already allotted to the teacher for the same section
                $check_sql = "SELECT COUNT(*) AS count FROM subject_allocation WHERE subject_code = ? AND section = ? AND teacher_id = ?";
                $check_stmt = $conn->prepare($check_sql);
                $check_stmt->bind_param("sss", $subject_code, $section, $toalloted);
                $check_stmt->execute();
                $check_result = $check_stmt->get_result();
                $row = $check_result->fetch_assoc();

                if ($row['count'] == 0) {
                    // If not allotted, proceed with insertion
                    $insert_sql = "INSERT INTO subject_allocation (subject_code, teacher_id, section) VALUES (?, ?, ?)";
                    $insert_stmt = $conn->prepare($insert_sql);
                    $insert_stmt->bind_param("sss", $subject_code, $toalloted, $section);
                    if (!$insert_stmt->execute()) {
                        throw new Exception("Error inserting record for subject $subject_code: " . $insert_stmt->error);
                    }
                }
            }
            // Commit transaction
            $conn->commit();
            // Redirect after processing
            header("Location: allotsubjects.php");
            exit();
        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollback();
            echo "Transaction failed: " . $e->getMessage();
        }
    } else {
        echo "Please select all required fields.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
    <meta name="description" content=""/>
    <meta name="author" content=""/>
    <title>TimeTable Management System</title>
    <!-- BOOTSTRAP CORE STYLE CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet"/>
    <!-- FONT AWESOME CSS -->
    <link href="assets/css/font-awesome.min.css" rel="stylesheet"/>
    <!-- CUSTOM STYLE CSS -->
    <link href="assets/css/style.css" rel="stylesheet"/>
    <!-- Google Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,300' rel='stylesheet' type='text/css'/>
    <style>
        body {
            font-family: 'Open Sans', sans-serif;
        }

        .form-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 100px;
        }

        .form-container select, .form-container button {
            margin: 5px;
        }

        table {
            margin-top: 80px;
            margin-bottom: 50px;
            font-family: Arial, sans-serif;
            border-collapse: collapse;
            width: 90%;
            margin-left: auto;
            margin-right: auto;
        }

        td, th {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        tr:nth-child(even) {
            background-color: #dddddd;
        }

        th {
            background-color: #f4f4f4;
            color: #333;
        }
    </style>
</head>
<body>

<div class="navbar navbar-inverse navbar-fixed-top " id="menu">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div class="navbar-collapse collapse move-me">
            <ul class="nav navbar-nav navbar-left">
                <li><a href="addteachers.php">ADD TEACHERS</a></li>
                <li><a href="addsubjects.php">ADD SUBJECTS</a></li>
                <li><a href="addclassrooms.php">ADD CLASSROOMS</a></li>
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">ALLOTMENT
                        <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="allotsubjects.php">THEORY COURSES</a></li>
                        <li><a href="allotpracticals.php">PRACTICAL COURSES</a></li>
                        <li><a href="allotclasses.php">CLASSROOMS</a></li>
                    </ul>
                </li>
                <li><a href="generatetimetable.php">GENERATE TIMETABLE</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="index.php">LOGOUT</a></li>
            </ul>
        </div>
    </div>
</div>
<!-- NAVBAR SECTION END -->

<div class="form-container">
    <form action="allotsubjects.php" method="post">
        <select name="toalloted" class="list-group-item">
            <option selected disabled>Select Teacher</option>
            <?php
            $conn = new mysqli("localhost", "root", "", "ttms");
            $result = $conn->query("SELECT * FROM teachers");
            while ($row = $result->fetch_assoc()) {
                echo "<option value='{$row['faculty_number']}'>{$row['name']}</option>";
            }
            $conn->close();
            ?>
        </select>

        <select name="subjects[]" class="list-group-item" multiple>
            <option selected disabled>Select Subjects</option>
            <?php
            $conn = new mysqli("localhost", "root", "", "ttms");
            $result = $conn->query("SELECT * FROM subjects WHERE course_type != 'LAB'");
            while ($row = $result->fetch_assoc()) {
                echo "<option value='{$row['subject_code']}'>{$row['subject_name']}</option>";
            }
            $conn->close();
            ?>
        </select>

        <select name="section" class="list-group-item">
            <option selected disabled>Select Section</option>
            <option value="A">A</option>
            <option value="B">B</option>
            <option value="C">C</option>
        </select>

        <button type="submit" class="btn btn-success btn-lg">Allot</button>
    </form>
</div>

<table id="allotedsubjectstable">
    <caption><strong>THEORY COURSES ALLOTMENT</strong></caption>
    <tr>
        <th>Subject Code</th>
        <th>Subject Title</th>
        <th>Faculty No</th>
        <th>Teacher's Name</th>
        <th>Section</th>
        <th>Action</th>
    </tr>
    <tbody>
    <?php
    $conn = new mysqli("localhost", "root", "", "ttms");
    $result = $conn->query("SELECT sa.subject_code, s.subject_name, sa.teacher_id, sa.section, t.name 
                            FROM subject_allocation sa 
                            JOIN subjects s ON sa.subject_code = s.subject_code 
                            JOIN teachers t ON sa.teacher_id = t.faculty_number");
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['subject_code']}</td>
                <td>{$row['subject_name']}</td>
                <td>{$row['teacher_id']}</td>
                <td>{$row['name']}</td>
                <td>{$row['section']}</td>
                <td>
                    <button onclick='deleteRow(\"{$row['subject_code']}\", \"{$row['section']}\")'>Delete</button>
                </td>
              </tr>";
    }
    $conn->close();
    ?>
    </tbody>
</table>

<script>
    function deleteRow(subjectCode, section) {
        if (confirm("Are you sure you want to delete this allocation?")) {
            window.location.href = "deleteallotment.php?subject_code=" + subjectCode + "&section=" + section;
        }
    }
</script>

<!-- JS scripts -->
<script src="assets/js/jquery-1.10.2.js"></script>
<script src="assets/js/bootstrap.js"></script>
<script src="assets/js/custom.js"></script>
</body>
</html>
