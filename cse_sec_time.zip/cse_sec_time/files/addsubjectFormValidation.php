<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'connection.php';

if (isset($_POST['SN']) && isset($_POST['SC']) && isset($_POST['SS']) && isset($_POST['ST']) && isset($_POST['max_per_week'])) {
    $name = $_POST['SN'];
    $code = $_POST['SC'];
    $sem = $_POST['SS'];
    $course = $_POST['ST'];
    $max_per_week = $_POST['max_per_week'];

    $conn = mysqli_connect("localhost", "root", "", "ttms");
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $sql = "INSERT INTO subjects (subject_code, subject_name, course_type, semester, department, isAlloted, max_per_week) VALUES (?, ?, ?, ?, 'Computer Engg.', 0, ?)";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("sssii", $code, $name, $course, $sem, $max_per_week);

    if ($stmt->execute()) {
        header("Location: addsubjects.php");
        exit();
    } else {
        die("Error: " . $stmt->error);
    }

    $stmt->close();
    mysqli_close($conn);
} else {
    die("Required fields are missing.");
}
?>
