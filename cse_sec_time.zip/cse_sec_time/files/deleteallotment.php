<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "ttms");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start the session
session_start();

// Get parameters from URL
$subject_code = isset($_GET['subject_code']) ? $_GET['subject_code'] : null;
$section = isset($_GET['section']) ? $_GET['section'] : null;

if ($subject_code && $section) {
    // Delete the record based on subject code and section
    $sql = "DELETE FROM subjects WHERE subject_code = ? AND section = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $subject_code, $section);

    if ($stmt->execute()) {
        header("Location: allotsubjects.php");
        exit();
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}

$conn->close();
?>
