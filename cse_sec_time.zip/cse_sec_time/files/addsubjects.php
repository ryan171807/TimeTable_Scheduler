<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
    <meta name="description" content=""/>
    <meta name="author" content=""/>
    <title>TimeTable Management System</title>
    <!-- BOOTSTRAP CORE STYLE CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet"/>
    <!-- FONT AWESOME CSS -->
    <link href="assets/css/font-awesome.min.css" rel="stylesheet"/>
    <!-- FLEXSLIDER CSS -->
    <link href="assets/css/flexslider.css" rel="stylesheet"/>
    <!-- CUSTOM STYLE CSS -->
    <link href="assets/css/style.css" rel="stylesheet"/>
    <!-- Google Fonts -->
    <style>
    .modal-content {
        margin-top: 1px; /* Move modal upwards */
    }

    .btn-delete {
            background-color: green; /* Green background */
            color: white; /* White text */
            border: none; /* No border */
        }

        .btn-delete:hover {
            background-color: darkgreen; /* Darker green on hover */
        }
    </style>
</head>
<body>

<div class="navbar navbar-inverse navbar-fixed-top " id="menu">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div class="navbar-collapse collapse move-me">
            <ul class="nav navbar-nav navbar-left">
                <li><a href="addteachers.php">ADD TEACHERS</a></li>
                <li><a href="addsubjects.php">ADD SUBJECTS</a></li>
                <li><a href="addclassrooms.php">ADD CLASSROOMS</a></li>
                <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">ALLOTMENT
                        <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="allotsubjects.php">THEORY COURSES</a></li>
                        <li><a href="allotpracticals.php">PRACTICAL COURSES</a></li>
                        <li><a href="allotclasses.php">CLASSROOMS</a></li>
                    </ul>
                </li>
                <li><a href="generatetimetable.php">GENERATE TIMETABLE</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="index.php">LOGOUT</a></li>
            </ul>
        </div>
    </div>
</div>
<!--NAVBAR SECTION END-->
<br>

<div align="center" style="margin-top:60px">
    <form name="import" method="post" enctype="multipart/form-data">
        <input type="file" name="file"/>
        <input type="submit" name="subjectexcel" id="subjectexcel" class="btn btn-info btn-lg" value="IMPORT EXCEL"/>
    </form>
    <?php
    if (isset($_POST['subjectexcel'])) {
        if (empty($_FILES['file']['tmp_name'])) {
            echo '<script>alert("Select a file first! ");</script>';
        } else {
            $file = $_FILES['file']['tmp_name'];
            $handle = fopen($file, 'r');
            while (!feof($handle)) {
                $filesop = fgetcsv($handle, 1000);
                $code = $filesop[0];
                $name = $filesop[1];
                $type = $filesop[2];
                $semester = $filesop[3];
                if ($code == "" || $code == "Subject Code") {
                    continue;
                }
                $conn = mysqli_connect("localhost", "root", "", "ttms");
                $q = mysqli_query($conn,
                    "INSERT INTO subjects (subject_code, subject_name, course_type, semester, department, isAlloted, max_per_week) VALUES ('$code', '$name', '$type', '$semester', 'Computer Engg.', 0, 1)");
                mysqli_close($conn);
            }
        }
    }
    ?>
</div>

<div align="center" style="margin-top: 20px">
    <button id="subjectmanual" class="btn btn-success btn-lg">ADD SUBJECT</button>
</div>

<div id="myModal" class="modal">
    <!-- Modal content -->
    <div class="modal-content">
        <div class="modal-header">
            <span class="close">&times</span>
            <h2 id="popupHead">Add Subject</h2>
        </div>
        <div class="modal-body" id="EnterSubject">
            <!--Admin Login Form-->
            <div style="display:none" id="addSubjectForm">
                <form action="addsubjectFormValidation.php" method="POST">
                    <div class="form-group">
                        <label for="subjectname">Subject Name</label>
                        <input type="text" class="form-control" id="subjectname" name="SN" placeholder="Subject's Name ...">
                    </div>
                    <div class="form-group">
                        <label for="subjectcode">Subject Code</label>
                        <input type="text" class="form-control" id="subjectcode" name="SC" placeholder="CO203 CO205...">
                    </div>
                    <div class="form-group">
                        <label for="subjecttype">Course Type</label>
                        <select class="form-control" id="subjecttype" name="ST">
                            <option selected disabled>Select</option>
                            <option value="THEORY">THEORY</option>
                            <option value="LAB">LAB</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="subjectsemester">Semester</label>
                        <select class="form-control" id="subjectsemester" name="SS">
                            <option selected disabled>Select</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                        </select>
                    </div>
                    <input type="hidden" name="SD" value="Computer Engg.">
                    <div class="form-group">
                        <label for="max_per_week">Max per Week</label>
                        <select class="form-control" id="max_per_week" name="max_per_week">
                            <option selected disabled>Select</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                        </select>
                    </div>
                    <div align="right" class="form-group">
                        <input type="submit" class="btn btn-default" name="ADD" value="ADD">
                    </div>
                </form>
            </div>
        </div>
        <div class="modal-footer">
        </div>
    </div>
</div>

<script>
    var modal = document.getElementById('myModal');
    var addsubjectBtn = document.getElementById("subjectmanual");
    var heading = document.getElementById("popupHead");
    var subjectForm = document.getElementById("addSubjectForm");
    var span = document.getElementsByClassName("close")[0];

    addsubjectBtn.onclick = function () {
        modal.style.display = "block";
        subjectForm.style.display = "block";
    }

    span.onclick = function () {
        modal.style.display = "none";
        subjectForm.style.display = "none";
    }

    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
</script>

<div>
    <br>
    <style>
        table {
            margin-top: 10px;
            font-family: arial, sans-serif;
            border-collapse: collapse;
            margin-left: 50px;
            width: 90%;
        }

        td, th {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        tr:nth-child(even) {
            background-color: #dddddd;
        }
    </style>

    <table>
        <caption><strong>Subjects</strong></caption>
        <tr>
            <th width="130">Subject Code</th>
            <th width="290">Subject Name</th>
            <th width="150">Type</th>
            <th width="150">Semester</th>
            <th width="150">Max per Week</th>
            <th width="100">Action</th> <!-- New column for action -->
        </tr>
        <?php
        $conn = mysqli_connect("localhost", "root", "", "ttms");
        $query = mysqli_query($conn, "SELECT * FROM subjects");
        while ($row = mysqli_fetch_assoc($query)) {
            echo "<tr>
            <td>{$row['subject_code']}</td>
            <td>{$row['subject_name']}</td>
            <td>{$row['course_type']}</td>
            <td>{$row['semester']}</td>
            <td>{$row['max_per_week']}</td>
            <td>
    <form method='post' action='delete_subject.php'>
        <input type='hidden' name='subject_code' value='{$row['subject_code']}'>
        <input type='submit' class='btn btn-danger btn-delete' value='Delete' onclick='return confirm(\"Are you sure you want to delete this subject?\");'>
    </form>
</td>

            </tr>";
        }
        mysqli_close($conn);
        ?>
    </table>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
</body>
</html>
