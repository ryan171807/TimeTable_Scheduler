<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ttms"; // Database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if all form values are set and not empty
    if (isset($_POST['teacher1'], $_POST['batch1'], $_POST['lab1'], $_POST['teacher2'], $_POST['batch2'], $_POST['lab2']) &&
        !empty($_POST['teacher1']) && !empty($_POST['batch1']) && !empty($_POST['lab1']) &&
        !empty($_POST['teacher2']) && !empty($_POST['batch2']) && !empty($_POST['lab2'])) {

        // Get form values
        $teacher1 = $_POST['teacher1'];
        $batch1 = $_POST['batch1'];
        $lab1 = $_POST['lab1'];
        $teacher2 = $_POST['teacher2'];
        $batch2 = $_POST['batch2'];
        $lab2 = $_POST['lab2'];

        // Check for uniqueness and inequality
        if ($teacher1 === $teacher2) {
            echo "<div class='alert alert-danger'>Teacher 1 cannot be the same as Teacher 2.</div>";
        } elseif ($batch1 === $batch2) {
            echo "<div class='alert alert-danger'>Batch 1 cannot be the same as Batch 2.</div>";
        } elseif ($lab1 === $lab2) {
            echo "<div class='alert alert-danger'>Lab 1 cannot be the same as Lab 2.</div>";
        } else {
            // Check if the combination already exists in the database
            $checkQuery = $conn->prepare("SELECT COUNT(*) FROM practical_allotment WHERE 
                (teacher1 = ? AND batch1 = ? AND lab1 = ?) AND 
                (teacher2 = ? AND batch2 = ? AND lab2 = ?)");
            $checkQuery->bind_param("ssssss", $teacher1, $batch1, $lab1, $teacher2, $batch2, $lab2);
            $checkQuery->execute();
            $checkQuery->bind_result($count);
            $checkQuery->fetch();
            $checkQuery->close();

            if ($count > 0) {
                echo "<div class='alert alert-danger'>This combination of teachers and batches already exists.</div>";
            } else {
                // Prepare and bind the SQL insert query
                $stmt = $conn->prepare("INSERT INTO practical_allotment (teacher1, batch1, lab1, teacher2, batch2, lab2) VALUES (?, ?, ?, ?, ?, ?)");
                if ($stmt) {
                    $stmt->bind_param("ssssss", $teacher1, $batch1, $lab1, $teacher2, $batch2, $lab2);

                    // Execute the statement
                    if ($stmt->execute()) {
                        echo "<div class='alert alert-success'>Allotment successfully saved!</div>";
                    } else {
                        echo "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
                    }

                    // Close statement
                    $stmt->close();
                } else {
                    echo "<div class='alert alert-danger'>Error preparing the statement: " . $conn->error . "</div>";
                }
            }
        }
    } else {
        echo "<div class='alert alert-danger'>Please fill in all fields.</div>";
    }
}

// Close connection
$conn->close();
?>
