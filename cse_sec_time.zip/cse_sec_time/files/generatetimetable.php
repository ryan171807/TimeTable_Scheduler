<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "ttms");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start the session
session_start();

// Get selected semester type from POST request
$selected_semester_type = isset($_POST['select_semester_type']) ? $_POST['select_semester_type'] : null;

// Define the semester groups based on the selected type
$semesters = [];
if ($selected_semester_type === 'odd') {
    $semesters = [3, 5, 7];
} elseif ($selected_semester_type === 'even') {
    $semesters = [ 4,6,8];
}

// Initialize sections array
$sections = ['A', 'B', 'C'];

// Fetch theory subjects and their limits for the specified semesters
$subjects = [];
foreach ($semesters as $semester) {
    $subjectsQuery = "SELECT subject_code, subject_name, max_per_week, semester 
                      FROM subjects 
                      WHERE course_type = 'THEORY' AND semester = $semester";
    $subjectsResult = $conn->query($subjectsQuery);
    
    if (!$subjectsResult) {
        die("Error fetching subjects: " . $conn->error);
    }

    // Initialize the array for the semester even if there are no subjects
    $subjects[$semester] = [];
    while ($row = $subjectsResult->fetch_assoc()) {
        $subjects[$semester][] = $row;
    }
}

// Fetch teacher allocation details, joining the subjects table to get the semester
$allocationQuery = "SELECT sa.subject_code, sa.teacher_id, t.name AS teacher_name, sa.section, s.semester
                    FROM subject_allocation sa
                    JOIN teachers t ON sa.teacher_id = t.faculty_number
                    JOIN subjects s ON sa.subject_code = s.subject_code";
$allocationResult = $conn->query($allocationQuery);

if (!$allocationResult) {
    die("Error fetching teacher allocation: " . $conn->error);
}

$allocations = [];
while ($row = $allocationResult->fetch_assoc()) {
    $allocations[$row['semester']][$row['section']][$row['subject_code']] = [
        'teacher_name' => $row['teacher_name'],
        'subject_name' => $row['subject_code'] . ": " . $row['subject_code']
    ];
}

// Fetch practical allotment details with semester_section and filter based on semester and section
$practicalIds = [];
foreach ($semesters as $semester) {
    foreach ($sections as $section) {
        $semesterSectionKey = $semester . $section;
        $practicalAllotmentQuery = "SELECT id, teacher1, teacher1_2,batch1, lab1, teacher2,teacher2_2, batch2, lab2
        FROM practical_allotment 
        WHERE semester_section = '$semesterSectionKey'";
        $practicalAllotmentResult = $conn->query($practicalAllotmentQuery);
        
        if (!$practicalAllotmentResult) {
            die("Error fetching practical allotment details: " . $conn->error);
        }

        while ($row = $practicalAllotmentResult->fetch_assoc()) {
            $practicalIds[$semesterSectionKey][$row['id']] = [
                'teacher1' => $row['teacher1'],
                'teacher1_2' => $row['teacher1_2'],
                'batch1' => $row['batch1'],
                'lab1' => $row['lab1'],
                'teacher2' => $row['teacher2'],
                'teacher2_2' => $row['teacher2_2'],
                'batch2' => $row['batch2'],
                'lab2' => $row['lab2'],
            ];
        }
    }
}

// Function to get random subjects
function getRandomSubjects($array, $count) {
    $keys = array_rand($array, min($count, count($array)));
    return array_map(function($key) use ($array) {
        return $array[$key];
    }, (array) $keys);
}

// Generate timetable for each section in each semester
$timetable = [];
$weekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
$periods = ['9:00-10:00', '10:00-11:00', '11:00-12:00', '12:00-1:00', '1:00-2:00', '2:00-3:00', '3:00-4:00', '4:00-5:00'];

// Keep track of practical IDs already assigned for the week
$assignedPracticalIds = [];

foreach ($semesters as $semester) {
    foreach ($sections as $section) {
        if (isset($subjects[$semester]) && !empty($subjects[$semester])) {
            $subjectCount = array_fill_keys(array_column($subjects[$semester], 'subject_code'), 0);
            $timetable[$semester][$section] = [];

            foreach ($weekdays as $day) {
                $daySchedule = [];
                $assignedSubjects = [];
                $availablePeriods = $periods;

                // Assign subjects to periods (ensuring all theory subjects are assigned first)
                foreach ($availablePeriods as $period) {
                    $availableSubjects = array_filter($subjects[$semester], function ($subject) use ($subjectCount) {
                        return $subjectCount[$subject['subject_code']] < $subject['max_per_week'];
                    });

                    $availableSubjects = array_filter($availableSubjects, function ($subject) use ($assignedSubjects) {
                        return !in_array($subject['subject_code'], $assignedSubjects);
                    });

                    // Check if we can assign a subject
                    if (empty($availableSubjects)) {
                        $daySchedule[$period] = "-";
                    } else {
                        $subject = getRandomSubjects($availableSubjects, 1)[0];
                        $assignedSubjects[] = $subject['subject_code'];
                        $teacherInfo = isset($allocations[$semester][$section][$subject['subject_code']]) 
                            ? $allocations[$semester][$section][$subject['subject_code']]['teacher_name'] 
                            : 'No teacher assigned';

                        $daySchedule[$period] = $subject['subject_code'] . ": " . $subject['subject_name'] . "<br>Teacher: " . $teacherInfo;
                        $subjectCount[$subject['subject_code']]++;
                    }
                }

                // Find the last theory period of the day
                $lastTheoryPeriodIndex = -1;
                foreach ($periods as $index => $period) {
                    if (isset($daySchedule[$period]) && $daySchedule[$period] !== "-") {
                        $lastTheoryPeriodIndex = $index;
                    }
                }
// Assign practicals if available for the section
$semesterSectionKey = $semester . $section;
if (isset($practicalIds[$semesterSectionKey]) && !empty($practicalIds[$semesterSectionKey])) {
    $availablePracticalIds = array_diff(array_keys($practicalIds[$semesterSectionKey]), $assignedPracticalIds);
    if (!empty($availablePracticalIds)) {
        $randomPracticalId = $availablePracticalIds[array_rand($availablePracticalIds)];

        // Check if we have space for a 2-period practical after the last theory period
        $practicalStartIndex = $lastTheoryPeriodIndex + 1;
        if ($practicalStartIndex < count($periods) - 1 && isset($periods[$practicalStartIndex + 1])) {
            // Fetch practical details
            $teacher1_2 = isset($row['teacher1_2']) ? $row['teacher1_2'] : null;
$teacher2_2 = isset($row['teacher2_2']) ? $row['teacher2_2'] : null;

            $practicalDetails = $practicalIds[$semesterSectionKey][$randomPracticalId];
            $daySchedule[$periods[$practicalStartIndex]] = "Practical ID: $randomPracticalId<br>Teacher 1: {$practicalDetails['teacher1']}<br>Teacher 1_2: {$practicalDetails['teacher1_2']}<br>Batch 1: {$practicalDetails['batch1']}<br>Lab 1: {$practicalDetails['lab1']}";
            $daySchedule[$periods[$practicalStartIndex + 1]] = "Practical ID: $randomPracticalId<br>Teacher 2: {$practicalDetails['teacher2']}<br>Teacher 2_2: {$practicalDetails['teacher2_2']}<br>Batch 2: {$practicalDetails['batch2']}<br>Lab 2: {$practicalDetails['lab2']}";
            $assignedPracticalIds[] = $randomPracticalId;
        }
    }
}

             
                // Prepare for lunch assignment
                // Find the number of filled slots for lunch assignment
                $filledSlots = array_filter($daySchedule, function ($value) {
                    return $value !== "-";
                });

                // Calculate middle slot for lunch only if we have enough periods
                if (count($filledSlots) > 3) { // Lunch only assigned if there are more than 3 classes
                    // Create an empty slot in the middle
                    $middleSlotIndex = (int) floor(count($filledSlots) / 2);
                    $periodKeys = array_keys($filledSlots);
                    $middlePeriod = $periodKeys[$middleSlotIndex];

                    // Shift all periods after the middle period one slot down to make space for lunch
                    for ($i = count($periods) - 1; $i > $middleSlotIndex; $i--) {
                        if (isset($daySchedule[$periods[$i - 1]])) {
                            $daySchedule[$periods[$i]] = $daySchedule[$periods[$i - 1]];
                        }
                    }
                    // Clear the middle slot for lunch
                    $daySchedule[$periods[$middleSlotIndex]] = "Lunch Break";
                }

                // Fill any remaining periods with "-"
                foreach ($periods as $period) {
                    if (!isset($daySchedule[$period])) {
                        $daySchedule[$period] = "-";
                    }
                }

                $timetable[$semester][$section][$day] = $daySchedule;
            }
        } else {
            // Initialize timetable with "-" if no subjects available
            foreach ($weekdays as $day) {
                $daySchedule = array_fill_keys($periods, "-");
                $timetable[$semester][$section][$day] = $daySchedule;
            }
        }
    }
}

// Close database connection
$conn->close();
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
    <meta name="description" content=""/>
    <meta name="author" content=""/>
    <title>TimeTable Management System</title>
    <!-- BOOTSTRAP CORE STYLE CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet"/>
    <!-- FONT AWESOME CSS -->
    <link href="assets/css/font-awesome.min.css" rel="stylesheet"/>
    <!-- FLEXSLIDER CSS -->
    <link href="assets/css/flexslider.css" rel="stylesheet"/>
    <!-- CUSTOM STYLE CSS -->
    <link href="assets/css/style.css" rel="stylesheet"/>
    <!-- Google Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,300' rel='stylesheet' type='text/css'/>
    <style>
        h2 {
            text-align: center;
            margin-top: 100px; /* Add some margin to move it down */
            margin-bottom: 20px; /* Optional: control space below the heading */
            font-weight: bold;
        }
        .table-container {
            display: flex;
            justify-content: center;
            margin-top: 100px;
        }

        .timetable-table {
            border-collapse: collapse;
            width: 100%;
            max-width: 1200px;
            font-size: 16px;
            border: 1px solid #ddd;
        }

        .timetable-table th, .timetable-table td {
            border: 1px solid #ddd;
            text-align: center;
            padding: 12px;
        }

        .timetable-table th {
            background-color: #f4f4f4;
            color: #333;
            font-weight: bold;
        }

        .timetable-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .timetable-table tr:nth-child(odd) {
            background-color: #ffffff;
        }

        .timetable-table td {
            vertical-align: top;
        }
    </style>
</head>
<body>

<div class="navbar navbar-inverse navbar-fixed-top " id="menu">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div class="navbar-collapse collapse move-me">
            <ul class="nav navbar-nav navbar-left">
                <li><a href="addteachers.php">ADD TEACHERS</a></li>
                <li><a href="addsubjects.php">ADD SUBJECTS</a></li>
                <li><a href="addclassrooms.php">ADD CLASSROOMS</a></li>
                <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">ALLOTMENT
                        <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="allotsubjects.php">THEORY COURSES</a></li>
                        <li><a href="allotpracticals.php">PRACTICAL COURSES</a></li>
                        <li><a href="allotclasses.php">CLASSROOMS</a></li>
                    </ul>
                </li>
                <li><a href="generatetimetable.php">GENERATE TIMETABLE</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="index.php">LOGOUT</a></li>
            </ul>
        </div>
    </div>
</div>
<!-- NAVBAR SECTION END -->
<br>
    <form action="generatetimetable.php" method="post">
        <div align="center" style="margin-top:100px">
            <select name="select_semester_type" class="list-group-item" onchange="this.form.submit()">
                <option selected disabled>Select Semester Type</option>
                <option value="odd">Odd Semesters (3, 5, 7)</option>
                <option value="even">Even Semesters (4,6,8)</option>
            </select>
        </div>
    </form>

    <?php if (!empty($timetable)): ?>
        <?php foreach ($timetable as $semester => $sections): ?>
            <?php foreach ($sections as $section => $weekSchedule): ?>
                <div class="table-container">
                    <table class="timetable-table">
                        <caption><h2><?php echo "Class Timetable for Semester " . $semester . " - Section " . $section; ?></h2></caption>
                        <thead>
                        <tr>
                            <th>Day/Period</th>
                            <?php foreach ($periods as $period): ?>
                                <th><?php echo ucfirst($period); ?></th>
                            <?php endforeach; ?>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($weekSchedule as $day => $daySchedule): ?>
                            <tr>
                                <td><?php echo $day; ?></td>
                                <?php foreach ($daySchedule as $period => $subject): ?>
                                    <td><?php echo $subject; ?></td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endforeach; ?>
        <?php endforeach; ?>
    <?php endif; ?>
</body>
</html>


