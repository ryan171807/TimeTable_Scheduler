<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
    <meta name="description" content=""/>
    <meta name="author" content=""/>
    <title>TimeTable Management System</title>
    <!-- BOOTSTRAP CORE STYLE CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet"/>
    <!-- FONT AWESOME CSS -->
    <link href="assets/css/font-awesome.min.css" rel="stylesheet"/>
    <!-- FLEXSLIDER CSS -->
    <link href="assets/css/flexslider.css" rel="stylesheet"/>
    <!-- CUSTOM STYLE CSS -->
    <link href="assets/css/style.css" rel="stylesheet"/>
    <!-- Google Fonts -->
    <style>
        .modal-content {
            margin-top: 1px; /* Move modal upwards */
        }

        .btn-delete {
            background-color: green; /* Green background */
            color: white; /* White text */
            border: none; /* No border */
        }

        .btn-delete:hover {
            background-color: darkgreen; /* Darker green on hover */
        }
    </style>
</head>
<body>

<div class="navbar navbar-inverse navbar-fixed-top " id="menu">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div class="navbar-collapse collapse move-me">
            <ul class="nav navbar-nav navbar-left">
                <li><a href="addteachers.php">ADD TEACHERS</a></li>
                <li><a href="addsubjects.php">ADD SUBJECTS</a></li>
                <li><a href="addclassrooms.php">ADD CLASSROOMS</a></li>
                <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">ALLOTMENT
                        <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="allotsubjects.php">THEORY COURSES</a></li>
                        <li><a href="allotpracticals.php">PRACTICAL COURSES</a></li>
                        <li><a href="allotclasses.php">CLASSROOMS</a></li>
                    </ul>
                </li>
                <li><a href="generatetimetable.php">GENERATE TIMETABLE</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="index.php">LOGOUT</a></li>
            </ul>
        </div>
    </div>
</div>
<!--NAVBAR SECTION END-->
<br>

<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ttms"; // Database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch teachers from the database
$teacher_query = "SELECT faculty_number, name FROM teachers";
$teacher_result = $conn->query($teacher_query);

// Store teachers in an array
$teachers = [];
if ($teacher_result && $teacher_result->num_rows > 0) {
    while ($row = $teacher_result->fetch_assoc()) {
        $teachers[] = $row;
    }
} else {
    echo "No teachers found!";
}

// Fetch labs from the database
$lab_query = "SELECT subject_name FROM subjects WHERE course_type = 'Lab'";
$lab_result = $conn->query($lab_query);

// Store labs in an array
$labs = [];
if ($lab_result && $lab_result->num_rows > 0) {
    while ($row = $lab_result->fetch_assoc()) {
        $labs[] = $row['subject_name'];
    }
} else {
    echo "No labs found!";
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['delete'])) {
        // Handle delete operation
        $id_to_delete = $_POST['delete'];
        $delete_query = "DELETE FROM practical_allotment WHERE id = '$id_to_delete'";
        if ($conn->query($delete_query) === TRUE) {
            echo "<div class='alert alert-success'>Allotment deleted successfully!</div>";
        } else {
            echo "<div class='alert alert-danger'>Error deleting allotment: " . $conn->error . "</div>";
        }
    } else {
        // Check if form inputs are set before using them
        $semester_section = isset($_POST['semester_section']) ? $_POST['semester_section'] : '';
        $teacher1 = isset($_POST['teacher1']) ? $_POST['teacher1'] : '';
        $batch1 = isset($_POST['batch1']) ? $_POST['batch1'] : '';
        $lab1 = isset($_POST['lab1']) ? $_POST['lab1'] : '';
        $teacher2 = isset($_POST['teacher2']) ? $_POST['teacher2'] : '';
        $batch2 = isset($_POST['batch2']) ? $_POST['batch2'] : '';
        $lab2 = isset($_POST['lab2']) ? $_POST['lab2'] : '';
        
        // Adding new teachers for labs
        $teacher1_2 = isset($_POST['teacher1_2']) ? $_POST['teacher1_2'] : '';
        $teacher2_2 = isset($_POST['teacher2_2']) ? $_POST['teacher2_2'] : '';

        // Insert allotment into the practical_allotment table
        $insert_query = "INSERT INTO practical_allotment (semester_section, teacher1, batch1, lab1, teacher1_2, teacher2_2, teacher2, batch2, lab2)
                         VALUES ('$semester_section', '$teacher1', '$batch1', '$lab1', '$teacher1_2', '$teacher2_2', '$teacher2', '$batch2', '$lab2')";
        if ($conn->query($insert_query) === TRUE) {
            echo "<div class='alert alert-success'>Allotment saved successfully!</div>";
        } else {
            echo "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
        }
    }
}

// Fetch all allotments from the database
$allotment_query = "SELECT a.id, a.semester_section, t1.name AS teacher1, a.batch1, a.lab1, 
                    t2.name AS teacher2, a.batch2, a.lab2,
                    a.teacher1_2, a.teacher2_2
                    FROM practical_allotment a
                    JOIN teachers t1 ON a.teacher1 = t1.faculty_number
                    JOIN teachers t2 ON a.teacher2 = t2.faculty_number";

$allotment_result = $conn->query($allotment_query);

// Check if the query was successful
if (!$allotment_result) {
    die("Error in query: " . $conn->error);
}

$conn->close();
?>

<form action="" method="post" style="margin-top: 100px">
    <div class="container">
        <div class="row text-center">
            <div class="col-md-6">
                <select name="semester_section" class="form-control">
                    <option selected disabled>Select Semester-Section</option>
                    <?php for ($semester = 3; $semester <= 8; $semester++): ?>
                        <?php foreach (['A', 'B', 'C'] as $section): ?>
                            <option value="<?= $semester . $section; ?>"><?= $semester . $section; ?></option>
                        <?php endforeach; ?>
                    <?php endfor; ?>
                </select>
            </div>
        </div>

        <div class="row text-center" style="margin-top: 15px">
            <!-- Teacher 1 dropdown -->
            <div class="col-md-6">
                <select name="teacher1" class="form-control">
                    <option selected disabled>Select Teacher 1</option>
                    <?php foreach ($teachers as $teacher): ?>
                        <option value="<?= htmlspecialchars($teacher['faculty_number']); ?>"><?= htmlspecialchars($teacher['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Teacher 2 dropdown -->
            <div class="col-md-6">
                <select name="teacher2" class="form-control">
                    <option selected disabled>Select Teacher 2</option>
                    <?php foreach ($teachers as $teacher): ?>
                        <option value="<?= htmlspecialchars($teacher['faculty_number']); ?>"><?= htmlspecialchars($teacher['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
 <!-- Batches and Labs -->
 <div class="row text-center" style="margin-top: 15px">
            <div class="col-md-6">
                <select name="batch1" class="form-control">
                    <option selected disabled>Select Batch 1</option>
                    <option value="A1/A2">A1/A2</option>
                    <option value="A3/A4">A3/A4</option>
                    <option value="B1/B2">B1/B2</option>
                    <option value="B3/B4">B3/B4</option>
                    <option value="C1/C2">C1/C2</option>
                    <option value="C3/C4">C3/C4</option>
                </select>
            </div>

            <div class="col-md-6">
                <select name="batch2" class="form-control">
                    <option selected disabled>Select Batch 2</option>
                    <option value="A1/A2">A1/A2</option>
                    <option value="A3/A4">A3/A4</option>
                    <option value="B1/B2">B1/B2</option>
                    <option value="B3/B4">B3/B4</option>
                    <option value="C1/C2">C1/C2</option>
                    <option value="C3/C4">C3/C4</option>
                </select>
            </div>
        </div>

        <div class="row text-center" style="margin-top: 15px">
            <div class="col-md-6">
                <select name="lab1" class="form-control">
                    <option selected disabled>Select Lab 1</option>
                    <?php foreach ($labs as $lab): ?>
                        <option value="<?= htmlspecialchars($lab); ?>"><?= htmlspecialchars($lab); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-6">
                <select name="lab2" class="form-control">
                    <option selected disabled>Select Lab 2</option>
                    <?php foreach ($labs as $lab): ?>
                        <option value="<?= htmlspecialchars($lab); ?>"><?= htmlspecialchars($lab); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>



        <!-- Teachers for Labs -->
        <div class="row text-center" style="margin-top: 15px">
            <div class="col-md-6">
                <select name="teacher1_2" class="form-control">
                    <option selected disabled>Select Teacher for Lab 1</option>
                    <?php foreach ($teachers as $teacher): ?>
                        <option value="<?= htmlspecialchars($teacher['faculty_number']); ?>"><?= htmlspecialchars($teacher['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-6">
                <select name="teacher2_2" class="form-control">
                    <option selected disabled>Select Teacher for Lab 2</option>
                    <?php foreach ($teachers as $teacher): ?>
                        <option value="<?= htmlspecialchars($teacher['faculty_number']); ?>"><?= htmlspecialchars($teacher['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

       

        <div class="row text-center" style="margin-top: 15px">
            <div class="col-md-12">
                <button type="submit" class="btn btn-success">Save Allotment</button>
            </div>
        </div>
    </div>
</form>
<br>


</form>

<!-- Allotments Table -->
<div class="container" style="margin-top: 50px">
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Semester-Section</th>
                <th>Teacher 1</th>
                <th>Teacher 1_2 for Lab 1</th>
                <th>Batch 1</th>
                <th>Lab 1</th>
                <th>Teacher 2</th>
                <th>Teacher 2_2 for Lab 2</th>
                <th>Batch 2</th>
                <th>Lab 2</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $allotment_result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['id']); ?></td>
                    <td><?= htmlspecialchars($row['semester_section']); ?></td>
                    <td><?= htmlspecialchars($row['teacher1']); ?></td>
                    <td><?= htmlspecialchars($row['teacher1_2']); ?></td>
                    <td><?= htmlspecialchars($row['batch1']); ?></td>
                    <td><?= htmlspecialchars($row['lab1']); ?></td>
                    <td><?= htmlspecialchars($row['teacher2']); ?></td>
                    <td><?= htmlspecialchars($row['teacher2_2']); ?></td>
                    <td><?= htmlspecialchars($row['batch2']); ?></td>
                    <td><?= htmlspecialchars($row['lab2']); ?></td>
                    <td>
                        <form method="post" action="">
                            <button type="submit" name="delete" value="<?= htmlspecialchars($row['id']); ?>" class="btn btn-delete">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<!-- JAVASCRIPT -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.js"></script>
</body>
</html>
